import { supabase } from '../lib/supabaseClient'
import {
  isTrainingAdmin,
  adminResetTraining,
  adminOverrideCompletion,
} from '../lib/adminDb'

if (import.meta.env.DEV) {
  window.lincAdminTest = {
    isTrainingAdmin,
    adminResetTraining,
    adminOverrideCompletion,
  }

  window.lincSupabase = supabase
}
