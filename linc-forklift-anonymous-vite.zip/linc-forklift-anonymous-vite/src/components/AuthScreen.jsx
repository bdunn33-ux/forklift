import { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function AuthScreen({ onTraineeInfo }) {
  const [fullName, setFullName] = useState('')
  const [employeeId, setEmployeeId] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  async function startTraining(e) {
    e.preventDefault()
    setError(null)

    const traineeInfo = {
      fullName: fullName.trim(),
      employeeId: employeeId.trim(),
    }

    if (!traineeInfo.fullName) {
      setError('Full name is required.')
      return
    }

    if (!traineeInfo.employeeId) {
      setError('Employee ID is required.')
      return
    }

    setLoading(true)

    try {
      localStorage.setItem('linc_trainee_info', JSON.stringify(traineeInfo))
      onTraineeInfo?.(traineeInfo)

      const { error } = await supabase.auth.signInAnonymously()
      if (error) throw error
    } catch (err) {
      setError(err.message || 'Failed to start training')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card">
      <h1>Forklift Training</h1>
      <p>Enter your information to begin. No email or password is required.</p>

      <form onSubmit={startTraining} className="stack">
        <label>
          Full name
          <input
            type="text"
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="First and last name"
          />
        </label>

        <label>
          Employee ID
          <input
            type="text"
            required
            value={employeeId}
            onChange={(e) => setEmployeeId(e.target.value)}
            placeholder="Employee ID"
          />
        </label>

        <button disabled={loading}>{loading ? 'Starting…' : 'Start Training'}</button>

        {error && <div className="notice err">{error}</div>}
      </form>

      <div className="notice warn">
        Complete the training on this same device/browser. If browser data is cleared,
        progress may not resume automatically.
      </div>
    </div>
  )
}
