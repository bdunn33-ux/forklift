import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './app/App.jsx'
import './index.css'

// This app does not use a service worker. If an older version of the site
// registered one, remove it so stale PWA/cache code cannot control this page.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations?.().then((registrations) => {
    registrations.forEach((registration) => registration.unregister())
  })
}

if ('caches' in window) {
  caches.keys?.().then((keys) => {
    keys.forEach((key) => caches.delete(key))
  })
}

// DEV-only console helpers. These should not attach in production.
if (import.meta.env.DEV) {
  import('./dev/installDevConsoleHelpers')
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
