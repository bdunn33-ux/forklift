# LINC Forklift Training

Vite + React + Supabase forklift training app.

This version uses **Supabase anonymous sign-in** instead of magic-link email sign-in. Users enter full name + employee ID, then start training without email/password.

## Netlify settings

Build command:

```text
npm run build
```

Publish directory:

```text
dist
```

Environment variables:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
```

## Supabase setup required

### 1. Enable anonymous auth

In Supabase dashboard, enable anonymous sign-ins under Authentication settings/providers.

### 2. Add employee_id column

Run:

```sql
alter table public.profiles
add column if not exists employee_id text;
```

A copy is included at:

```text
supabase/anonymous_auth_migration.sql
```

## User flow

1. User opens app.
2. Enters full name + employee ID.
3. Clicks Start Training.
4. App signs in anonymously.
5. App creates profile row with:
   - id = auth user id
   - full_name
   - employee_id
   - email = null
   - role = operator
6. Progress, quiz attempts, and completion records are saved by user_id.

## Important anonymous-auth note

Users should complete training on the same device/browser. If they clear browser data, sign out, or switch devices, they may not resume the same anonymous session.

## Required final wording

The app should show:

```text
Formal Training Complete — Hands-on evaluation still required
```

The lite app should not tell the user they are fully certified.

## Production verification

On the deployed Netlify site, open console and verify:

```js
window.lincAdminTest === undefined
window.lincSupabase === undefined
```

Both should be true.

## Admin panel

Trainer/Admin Tools only render if `isTrainingAdmin()` returns true.

Security is enforced by database RPCs, not by hidden UI.

Admin actions:

- Reset Training: resets progress and removes completion row. Quiz attempts are preserved unless wipeAttempts is checked.
- Override Formal Completion: marks formal training complete while hands-on evaluation remains required.
