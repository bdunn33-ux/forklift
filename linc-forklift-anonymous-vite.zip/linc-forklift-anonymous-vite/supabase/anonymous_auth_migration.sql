-- Required for no-email anonymous training flow.
-- Run in Supabase SQL Editor.

alter table public.profiles
add column if not exists employee_id text;

-- Optional sanity check:
select column_name, data_type
from information_schema.columns
where table_schema = 'public'
  and table_name = 'profiles'
order by ordinal_position;
